var bannerBG;
var bannerBorder;
function colorBanner(borderColor, backgroundImage, decoration){
  document.getElementById("banner").style.borderColor = borderColor;
  document.getElementById("banner2").style.backgroundColor = borderColor;
  document.getElementById("banner").style.backgroundImage = backgroundImage;
  console.log(borderColor, backgroundImage);
}
function randomRGB(){
  var color1 = parseFloat(Math.floor(Math.random() * 255));
  var color2 = parseFloat(Math.floor(Math.random() * 255));
  var color3 = parseFloat(Math.floor(Math.random() * 255));
  var rgb = `rgb(${color1}, ${color2}, ${color3})`;
  return(rgb);
}
function randomGradient(){
  if(Math.random() > 0.5){
    return `radial-gradient(${randomRGB()}, ${randomRGB()})`;
  }else{
    return `linear-gradient(${randomRGB()}, ${randomRGB()})`;
  }
}
function showProfile(){
  Elements = document.querySelectorAll('.profile');
  Elements.forEach(function(element) {
  element.style.visibility = "visible";
  element.style.pointerEvents = "all";
  });
}
function hideProfile(){
  Elements = document.querySelectorAll(".profile");
  Elements.forEach(function(element) {
  element.style.visibility = "hidden";
  element.style.pointerEvents = "none";
  });
}
function profile(){
  var rect = document.getElementById("board").getBoundingClientRect();
  var handRect = document.getElementById("hand").getBoundingClientRect();
  var page = document.createElement("div");
  document.getElementById("hand").style.left = `${rect.left}px`;
  document.getElementById("hand").style.top = `${rect.bottom}px`;
  page.setAttribute("id", "page");
  page.setAttribute("class", "profile");
  page.style.width = `${rect.width}px`;
  page.style.height = `${rect.height + handRect.height}px`;
  page.style.position = "absolute";
  page.style.backgroundColor = "#306a96";
  page.style.left = `${rect.left + window.scrollX}px`;
  page.style.top = `${rect.top + window.scrollY}px`;
  page.style.display = "flex";
  page.style.flexWrap=  "wrap";
  page.style.boxSizing = "border-box";
  page.style.border = "6px solid black";
  document.body.appendChild(page);
  var topBar = document.createElement("div");
  topBar.style.width = "120%";
  topBar.setAttribute("class", "profile");
  topBar.style.backgroundImage = "url('images/profiletop.png')";
  topBar.style.backgroundRepeat = "no-repeat";
  topBar.style.backgroundSize = "100% 100%";
  topBar.style.height = "15%";
  topBar.style.alignSef = "flex-start";
  topBar.style.marginLeft = "2.75%";
  topBar.style.marginBottom = "10%";
  topBar.setAttribute("onclick", "showBP(), hideProfile()");
  page.appendChild(topBar);
  var banner = document.createElement("div");
  banner.setAttribute("class", "profile");
  banner.setAttribute("id", "pfBanner")
  banner.style.boxSizing = "border-box";
  banner.style.opacity = "1";
  banner.style.border = `7px solid ${bannerBorder}`;
  banner.style.backgroundImage = bannerBG;
  banner.style.width = "75%";
  banner.style.height = "18%";
  banner.style.marginLeft = "2.5%";
  //banner.style.marginTop = "26%";
  banner.style.alignSelf = "flex-start";
  banner.style.order = "2";
  banner.style.clipPath = 'polygon(0% 0%, 100% 0%, 80% 50%, 100% 100%,0% 100%)';
  page.appendChild(banner);
  var bannerRect = banner.getBoundingClientRect();
//  var statDisplay = document.createElement("div");
  var banner2 = document.createElement("div");
  banner2.setAttribute("class", "profile");
  banner2.setAttribute("id", "pfBanner2");
  banner2.style.marginLeft = "2%";
  banner2.style.height = "18%";
  banner2.style.width = "75%";
  banner2.style.order = "0";
  banner2.style.marginTop = "36.5%";
  banner2.style.alignSelf = "flex-start";
  banner2.style.position = "absolute";
  banner2.style.backgroundColor = bannerBorder;
  banner2.style.clipPath = 'polygon(0% 0%, 104% 0%, 85% 50%, 104% 100%, 0% 100%)';
  page.appendChild(banner2);
  var name = document.createElement("h1");
  name.setAttribute("class", "profile");
  name.innerText = `${"Name123456"}`;
  name.style.fontSize = "32px";
  name.style.color = "white";
  name.style.order = "3";
  name.style.margin = "auto";
  name.style.marginTop = "8%";
  name.style.marginBottom = "8%";
  page.appendChild(name);
  
  var arena = document.createElement("div");
  arena.setAttribute("id", "arena");
  arena.setAttribute("class", "profile");
  var arenabox = arena.getBoundingClientRect();
  arena.style.width = "70%";
  arena.style.height = "35%";
  arena.style.marginLeft = "15%";
  arena.style.marginRight = "15%";
  arena.style.marginBottom = "70%";
  arena.style.alignSelf = "center";
  arena.style.order = "4";
  arena.style.display = "grid";
  arena.style.gridTemplateColumns = "1fr 1fr";
  arena.style.rowGap = "5px";
  arena.style.border = "4px solid blue";
  //arena.style.backgroundColor = "blue";
  //arena.style.opacity = "0.2";
  var clan = document.createElement("div")
  clan.style.gridColumn = "1 / span 2";
  clan.style.border = "4px solid black";
  clan.style.backgroundColor = "rgba(0,0,0,0.6)";
  clan.style.height = "24%";
  clan.style.margin = "0%";
  clan.innerHTML = '<h1 style="opacity:0.7;font-size: 20px; color:white";><em>____</em>Clans Coming "Soon"</h1>';
  var trophyCount = document.createElement("div");
  trophyCount.style.borderRadius = "75%";
  trophyCount.style.border = "4px solid black" 
  trophyCount.style.height = "24%";
  trophyCount.style.marginTop = "0%";
//  trophyCount.style.marg
  trophyCount.style.backgroundColor = "rgba(0,0,0,0.6)";
  trophyCount.style.gridArea = "2 / 1 / span 1 / span 2"
  arena.appendChild(clan);
  arena.appendChild(trophyCount);
  page.appendChild(arena);
  
}

// Clan and Clan stats
// Trophies and Arena
/* Path of legends
*/
// Battles won 