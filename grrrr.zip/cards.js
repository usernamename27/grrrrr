cardsOnBoard =[]; // List of all troops / buildings on board (the divs)

troopParams = [
  // Name, Speed, Damage,range, attack speed, splash radius, health, count
  Knight = ["Knight", 1.7, 202, 15, 1.1, 0, 1766, 1]
]
cardsInGame = [
  spells = [
  {type: "spell", name: "Arrows", elixirCost: 3, radius: 40, color: "rgba(200,200,200,0.8)", duration: 400, flySpeed: 3.5, damage: 366, towerDmg: 111},
  {type: "spell", name: "Clone", elixirCost: 3, radius: 25, color: "rgba(20,180,180,0.6)", duration: 300, flySpeed: 15, damage: 0, towerDmg: 0 },
  {type: "spell", name: "Freeze", elixirCost: 4, radius: 31, color: "rgba(180,180,255,0.8)", duration: 4000, flySpeed: 15, damage: 115, towerDmg: 35 },
  {type: "spell", name: "Fireball", elixirCost: 4, radius: 31, color: "rgba(240,130,18,0.8)", duration: 400, flySpeed: 3, damage: 689, towerDmg: 207},
  {type: "spell", name: "Rage", elixirCost: 2, radius: 33, color: "rgba(240,20,240,0.7)", duration: 6000, flySpeed: 15, damage: 192, towerDmg: 58 },
  {type: "spell", name: "GiantSnowball", elixirCost: 2, radius: 25, color: "rgba(240,240,240, 0.7)", duration: 200, flySpeed: 3, damage: 179, towerDmg: 54 },
  {type: "spell", name: "Rocket", elixirCost: 6, radius: 18, color: "rgba(250,0,0,0.7)", duration: 600, flySpeed: 2, damage: 1474, towerDmg: 371 },
  {type: "spell", name: "Zap", elixirCost: 2, radius: 23, color: "rgba(20,40,220,0.7)", duration: 110, flySpeed: 15, damage: 192, towerDmg: 58 }
  ],
  troops = [
    {name: "Knight", type: "troop", list: troopParams[0], elixirCost: 3}
  ]
];

deck = [
  cardsInGame[1][0],
  cardsInGame[0][1],
  cardsInGame[0][2],
  cardsInGame[0][3],
  cardsInGame[0][4],
  cardsInGame[0][5],
  cardsInGame[0][6],
  cardsInGame[0][0]
]
class Spell {
  constructor(name, flySpeed, damage, towerDmg, radius, color, duration, count, startTile, endTileNum, speedChange, atsChange, ticks){
    this.name = `${name}${count}`;
    this.damage = damage;
    this.towerDmg = towerDmg;
    this.flySpeed = flySpeed;
    this.ticks = ticks;
    this.radius = radius;
    this.atsChange = atsChange;
    this.speedChange = speedChange;
    var startTile = document.getElementById("kingBottom");
    var endTile = (typeof endTileNum != "number") ? document.getElementById(endTileNum): document.getElementById(`tile${endTileNum}`);
    var startTileRect = startTile.getBoundingClientRect();
    var endTileRect = endTile.getBoundingClientRect();

    var startOffsetX = (startTile.offsetWidth - 2 * radius) / 2;
    var startOffsetY = (startTile.offsetHeight - 2 * radius) / 2;
    var endOffsetX = (endTile.offsetWidth - 2 * radius) / 2;
    var endOffsetY = (endTile.offsetHeight - 2 * radius) / 2;

    var circle = document.createElement("div");
    circle.setAttribute("id", this.name);
    circle.style.width = `${2 * radius}px`;
    circle.style.height = `${2 * radius}px`;
    circle.style.borderRadius = "50%";
    circle.style.position = "absolute";
    circle.style.backgroundColor = color;
    circle.style.left = `${startTileRect.left + window.pageXOffset + startOffsetX}px`;
    circle.style.top = `${startTileRect.top + window.pageYOffset + startOffsetY}px`;
  }
  flyToEnd(name, flySpeed){
    var horizontalDistance = endTileRect.left + window.scrollX + endOffsetX - startTileRect.left - window.scrollX - startOffsetX;
    var verticalDistance = endTileRect.top + window.scrollY + endOffsetY - startTileRect.top - window.scrollX - startOffsetY;
    var distance = (Math.sqrt((verticalDistance*verticalDistance)+(horizontalDistance*horizontalDistance))); // pythagorean theorem !!

    var frames = (distance*3)/flySpeed;
    var frameCount = 0;

    // Calculate the rate of change for x and y positions
    var dx = (endTileRect.left + window.pageXOffset + endOffsetX - startTileRect.left - window.pageXOffset - startOffsetX) / frames;
    var dy = (endTileRect.top + window.pageYOffset + endOffsetY - startTileRect.top - window.pageYOffset - startOffsetY) / frames;
    /* Log info */ //console.log(distance, frames, horizontalDistance, verticalDistance, dx, dy);
    var interval = setInterval(() => {
    frameCount++;
    if (frameCount < frames) {
      circle.style.left = `${parseFloat(circle.style.left) + dx}px`;
      circle.style.top = `${parseFloat(circle.style.top) + dy}px`;
    } else {
      clearInterval(interval); // clear the interval
      // handle collision and animation end
      this.onHit(this.damage, this.towerDmg, this.speedChange, this.atsChange);
      circle.style.animation = `leave ${duration}ms`;
      circle.style.animationFillMode = "forwards";
      setTimeout(() => {
      removeCircle(); // remove the circle after the animation duration
      }, duration); // this will execute after the specified duration
    }
    }, 7.5 / flySpeed);
    function removeCircle() {
      document.body.removeChild(circle); // remove the circle after the animation duration
    }
  }
  onHit(damage, towerDmg, speedChange, atsChange){

  }
}
class Troop {
  constructor(name, speed, damage, range, ats, splashRadius, health, count, tileNum){
    this.name = `${name}${count}`;
    this.speed = speed;
    this.damage = damage;
   // this.elixirCost = elixirCost;
    this.range = range;
    this.splashRadius = splashRadius;
    this.ats = ats;
    this.health = health;
    this.startTileNum = tileNum;
    this.speedMult = 1;
    this.atsMult = 1;
    this.attackInterval;
    this.checkAtkInterval;
    this.attacking;
  //  this.interval = null;
    var startTile = (typeof tileNum != "number") ? document.getElementById(tileNum) : document.getElementById(`tile${tileNum}`);
    var startOffsetX = (startTile.offsetWidth - 2 * 9) / 2;
    var startOffsetY = (startTile.offsetHeight - 2 * 9) / 2;
    var startTileR = startTile.getBoundingClientRect();
    this.x = startTileR.x + window.scrollX + startOffsetX;
    this.y = startTileR.y + window.scrollY + startOffsetY;
    var circle = document.createElement("div");
    circle.setAttribute("id", `${this.name}`);
    circle.style.width = `${2 * 9}px`;
    circle.style.height = `${2 * 9}px`;
    circle.style.borderRadius = "50%";
    circle.style.position = "absolute";
    circle.style.backgroundColor = "gray";
    circle.style.left = `${this.x}px`;
    circle.style.top = `${this.y}px`;
    document.body.appendChild(circle);
    this.div = circle;
    var healthBar = document.createElement("div");
    healthBar.setAttribute("class", "health-bar");
    healthBar.style.width = `${(this.health / 60)}px`;
    healthBar.style.height = "5px";
    healthBar.style.left = "50%";
    healthBar.style.transform = "translateX(-50%)";
    healthBar.style.backgroundColor = "deepskyblue";
    healthBar.style.position = "absolute";
    healthBar.style.top = `${-10}px`;
    this.div.appendChild(healthBar); 
    this.hpbar = healthBar;
    
    cardsOnBoard.push(circle);
  }
  closestDistance(name) {
    var closestDistance = Infinity;
    var closestElement = "DefaultValue";
    var troop = document.getElementById(`${name}`);

    let checkClosestElement = (element, distance) => {
        if (distance < closestDistance) {
            closestDistance = distance;
            closestElement = element;
        }
    };

    cardsOnBoard.forEach(function(element) {
      if (element !== troop) {
        var distance = getDistance(troop, element)[0];
        checkClosestElement(element, distance);
      }
    });

    var endElements = [
      kingTop,
      princess1top,
      princess2top
    ];

    endElements.forEach(function(endElement) {
      if(endElement.health > 0){
      var distance = getDistance(troop, endElement.div)[0];
      checkClosestElement(endElement, distance);
      }
    });

    var bridge1 = document.getElementById("bridge1");
    var bridge2 = document.getElementById("bridge2");
    var distance1 = getDistance(troop, bridge1)[0];
    var distance2 = getDistance(troop, bridge2)[0];

    var closestBridge = distance2 < distance1 ? bridge2 : bridge1;

    var vertical = getDistance(troop, closestBridge)[2];

    var river = document.getElementById("river2");

    var toBridge = false;
    if(closestElement.div){
      var rect = closestElement.div.getBoundingClientRect();
    } else {
      var rect = closestElement.getBoundingClientRect();
    }
    if (Math.sign(rect.top - river.getBoundingClientRect().top) !== Math.sign(troop.getBoundingClientRect().top - river.getBoundingClientRect().top) && Math.sign(vertical) === -1) {
      toBridge = true;
    }

    var horizontalDistance = getDistance(troop, closestElement)[1];
    var verticalDistance = getDistance(troop, closestElement)[2];
    var closestElemRect = closestElement.div ? closestElement.div : closestElement;
    return [closestDistance, horizontalDistance, verticalDistance, closestElement, closestElemRect, toBridge, closestBridge];
  }
  move(name, range, speed, distance, horizontalDistance, verticalDistance, closestElement, endTileRect, toBridge, closestBridge) {
    this.hpbar.style.width = `${(this.health / 60)}px`;
    var circle = document.getElementById(`${name}`);
    var troop = circle;

    if (toBridge) {
      var closestDest = closestBridge;
    } else {
      if(closestElement.div){
        var closestDest = closestElement.div;
      }
      else {
        var closestDest = closestElement;
      }
    }
    //console.log(closestElement);
    var [distance, horizontalDistance, verticalDistance] = getDistance(troop, closestDest);
    var dx = speed * Math.sign(horizontalDistance);
    var dy = speed * Math.sign(verticalDistance);

    if (Math.abs(distance) > range) {
      var ratio = horizontalDistance / verticalDistance || 1;

      dy = verticalDistance === 0 ? 0 : dy;
      dx = horizontalDistance === 0 ? 0 : dx;

      if (Math.abs(ratio) > 1) {
        this.x += dx * this.speedMult;
        this.y += dy / Math.abs(ratio) * this.speedMult;
      } else {
        this.x += dx * Math.abs(ratio) * this.speedMult;
        this.y += dy * this.speedMult;
      }

      circle.style.left = `${parseFloat(this.x)}px`;
      circle.style.top = `${parseFloat(this.y)}px`;
    } else {
      if (toBridge) {
        var [distance, horizontalDistance, verticalDistance] = getDistance(troop, closestBridge);

        var dx = speed * Math.sign(horizontalDistance);
        var dy = speed * Math.sign(verticalDistance);
        var ratio = horizontalDistance / verticalDistance || 1;

        dy = verticalDistance === 0 ? 0 : dy;
        dx = horizontalDistance === 0 ? 0 : dx;
        verticalDistance = Math.abs(verticalDistance);

        if (Math.abs(ratio) > 1) {
          this.x += dx * this.speedMult;
          this.y += dy / Math.abs(ratio) * this.speedMult;
        } else {
          this.x += dx * Math.abs(ratio) * this.speedMult;
          this.y += dy * this.speedMult;
        }

        circle.style.left = `${parseFloat(this.x)}px`;
        circle.style.top = `${parseFloat(this.y)}px`;
      } else {
        circle.style.background = "red";
      }
    }
  }
  checkAttack(range, distance) {
      // Check if the troop is within range to attack
      var troop = this;
      if (Math.abs(distance) <= range) {
          if (!this.attacking) {
            this.attacking = true;
              this.attackInterval = setInterval(() => {
                  this.attacking = true;
                  this.attack(this.ats, this.splashRadius, this.damage, this.range, distance, this.closestDistance(troop.name)[3]);
              }, 1000 / this.ats);
          } 
      } else {
        clearInterval(troop.attackInterval); 
        this.attacking = false;
      }
      
  }
  attack(ats, splashRadius, damage, range, distance, closestElem) {
      var troop = this;
      if (Math.abs(distance) < range) {
          var start = document.getElementById(`${this.name}`);
          var closestElement = closestElem;

          

          if (closestElement.div) {
              if (closestElement.health <= damage) {
                  closestElement.taken();
              }
          } 
          if(closestElement.health > 0){
            closestElement.health -= damage;
          }
          if (splashRadius !== 0) {
              console.log("Handling splash damage later");
          }
      }
  }
}
class Building {
  constructor(name, length, width, elixirCost, expireRate, damage, health, range, x, y){
    this.expireRate = expireRate;
    this.elixirCost = elixirCost;
    this.damage = damage;
    this.health = health;
    this.length = length;
    this.width = width;
    this.range = range;
    if(spawner){
      this.spawnRate = spawnRate;
      this.spawn = spawn;
    }
  }
  attack(range, x, y, length, width, damage){
    /* 
    1. if a target is within the range, attack
    2. check if atarget is still in range > setTimeout for next attack
    */
  }
}

function getDistance(startElem, endElem){
  var startTile = startElem;
  if(endElem){
    var endTile = (endElem.div) ? endElem.div : endElem;
    var startTileRect = startTile.getBoundingClientRect();
    var endTileRect = endTile.getBoundingClientRect();
    var startOffsetX = (startTile.offsetWidth) / 2;
    var startOffsetY = (startTile.offsetHeight) / 2;
    var endOffsetX = (endTile.offsetWidth) / 2;
    var endOffsetY = (endTile.offsetHeight) / 2;
    var targetBridge = (endTile.id.includes("bridge"));

    var closestY = (startTileRect.top > endTileRect.top || targetBridge) ? endTileRect.top : endTileRect.bottom;
    var closestX = (startTileRect.left > endTileRect.left || targetBridge) ? endTileRect.left : endTileRect.right;

    horizontalDistance = closestX + endOffsetX - startTileRect.left + startOffsetX;
    verticalDistance = closestY + endOffsetY - startTileRect.top + startOffsetY;
    if(targetBridge){horizontalDistance -= 1.5*endOffsetX}
    distance = Math.sqrt(verticalDistance * verticalDistance + horizontalDistance * horizontalDistance);

    return [distance, horizontalDistance, verticalDistance];
  } else {
    return [Infinity, Infinity, Infinity];
  }

}
function detectCollision(circle, id) {
  var circleRect = circle.getBoundingClientRect();
  var towerRect = document.getElementById(id).getBoundingClientRect();
  var dx = circleRect.left + circleRect.width / 2 - Math.max(towerRect.left, Math.min(circleRect.left + circleRect.width / 2, towerRect.right));
  var dy = circleRect.top + circleRect.height / 2 - Math.max(towerRect.top, Math.min(circleRect.top + circleRect.height / 2, towerRect.bottom));
  return (dx * dx + dy * dy) < (circleRect.width / 2 * circleRect.width / 2);
}

function playBuilding(tileNum, length, width, HP, expireRate){

}
function playTroop(tileNum, list){
  var troopvar = `${list[0]}${list[7]}`;
  //console.log(troopvar);
  cardVar[troopvar] = new Troop(...list, tileNum);
  var troop = cardVar[troopvar];
  troop.checkAtkInterval = setInterval(function(){
    troop.checkAttack(troop.range, troop.closestDistance(troop.name)[0]);
  }, 100);
  setInterval(function(){
    troop.move(troop.name, troop.range, troop.speed, ...troop.closestDistance(troop.name));
  }, 100);
  list[7]++;
}
function playSpell(endTileNum, radius, color, duration, flySpeed, damage, towerDmg) {
  var startTile = document.getElementById("kingBottom");
  var endTile = (typeof endTileNum != "number") ? document.getElementById(endTileNum): document.getElementById(`tile${endTileNum}`);
  var startTileRect = startTile.getBoundingClientRect();
  var endTileRect = endTile.getBoundingClientRect();

  var startOffsetX = (startTile.offsetWidth - 2 * radius) / 2;
  var startOffsetY = (startTile.offsetHeight - 2 * radius) / 2;
  var endOffsetX = (endTile.offsetWidth - 2 * radius) / 2;
  var endOffsetY = (endTile.offsetHeight - 2 * radius) / 2;

  var circle = document.createElement("div");
  circle.style.width = `${2 * radius}px`;
  circle.style.height = `${2 * radius}px`;
  circle.style.borderRadius = "50%";
  circle.style.position = "absolute";
  circle.style.backgroundColor = color;
  circle.style.left = `${startTileRect.left + window.pageXOffset + startOffsetX}px`;
  circle.style.top = `${startTileRect.top + window.pageYOffset + startOffsetY}px`;


  document.body.appendChild(circle);
  var horizontalDistance = endTileRect.left + window.scrollX + endOffsetX - startTileRect.left - window.scrollX - startOffsetX;
  var verticalDistance = endTileRect.top + window.scrollY + endOffsetY - startTileRect.top - window.scrollX - startOffsetY;
  var distance = (Math.sqrt((verticalDistance*verticalDistance)+(horizontalDistance*horizontalDistance))); // pythagorean theorem !!

  var frames = (distance*3)/flySpeed;
  var frameCount = 0;

  // Calculate the rate of change for x and y positions
  var dx = (endTileRect.left + window.pageXOffset + endOffsetX - startTileRect.left - window.pageXOffset - startOffsetX) / frames;
  var dy = (endTileRect.top + window.pageYOffset + endOffsetY - startTileRect.top - window.pageYOffset - startOffsetY) / frames;
  /* Log info */ //console.log(distance, frames, horizontalDistance, verticalDistance, dx, dy);
  var interval = setInterval(() => {
  frameCount++;
  if (frameCount < frames) {
    circle.style.left = `${parseFloat(circle.style.left) + dx}px`;
    circle.style.top = `${parseFloat(circle.style.top) + dy}px`;
  } else {
    clearInterval(interval); // clear the interval
    // handle collision and animation end
    if(detectCollision(circle, "kingTop")) {
    handleCollision("kingTop", towerDmg);
    }
    if(detectCollision(circle, "princess1top")) {
    handleCollision("princess1top", towerDmg);
    }
    if(detectCollision(circle, "princess2top")) {
    handleCollision("princess2top", towerDmg);
    }
    circle.style.animation = `leave ${duration}ms`;
    circle.style.animationFillMode = "forwards";
    setTimeout(() => {
    removeCircle(); // remove the circle after the animation duration
    }, duration); // this will execute after the specified duration
  }
  }, 7.5 / flySpeed);
  function handleCollision(id, value) {
    if (id) {
    topTowers.forEach(function(tower){
      if(id == tower.div.id){
        if(tower.health > value){
          tower.health -= value;
        } else {
          tower.health = 0;
          tower.taken();
        }
      }
    });
    }
  }
  function removeCircle() {
    document.body.removeChild(circle); // remove the circle after the animation duration
  }
  }