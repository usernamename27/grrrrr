var playerName = "DefaultName";
var row = 0;
var nextCard;
var slot1;
var slot2;
var slot3;
var slot4;
var tiebreakerInterval;
var label;
var tieBreaker = false;
var elixirCount=10;
var selectedSlot;
var kingTop;
var princess1top;
var princess2top;
var kingBottom;
var princess1bottom;
var princess2bottom;
var redTowers = 0;
var blueTowers = 0;
// towersRed = [];
// towersBlue = [];
var trophies = 293;
var secondsLeft = 180;
var timeLeft = '3:00';
var overtime = false;
var elixirInterval;
var timeInterval;
var updateslotInterval;
var cardVar = {};
var newArenaReached = false;
const statFormula = "Math.floor(100*(1.1^level))";

class TowerTop {
  constructor(health, id, king){
    var tower = document.createElement("div");
    tower.setAttribute("id", id);
    var tiles = king ? 16 : 9;
    towerGrid(tower, tiles);
    document.getElementById("board").appendChild(tower);
    var ec = king ? "auto;" : ";";
    tower.style.cssText = "display: grid; grid-template-columns: auto auto auto" + ec;
    this.health = health;
    this.div = document.getElementById(id);
    this.king = king;
  }
  taken(){
    tower = this.div;
    tower.style.backgroundImage = 'url("images/destroyedTower.png")';
    tower.style.backgroundRepeat = "no-repeat";
    tower.style.backgroundSize = "100% 100%";
    document.getElementById(`${this.id}text`).style.opacity = "0%";
    if(this.king){
      princess1top.health = 0;
      princess2top.health = 0;
      princess1top.taken();
      princess2top.taken();
      winthing();
    }
  }
}
function startGame(){
  elixirInterval = setInterval(countElixir, 2800);
  timeInterval = setInterval(timeDown, 1000);
  updateslotInterval = setInterval(updateSlots, 50);
  // TOP
  for(let i = 1; i < 219; i++){
	var tile = document.createElement("div");
	tile.setAttribute("id", `tile${i}`);
	tile.setAttribute("onclick", `cardPlayed(selectedSlot, ${i})`);
  tile.setAttribute("onmouseover", `hovering(selectedSlot, ${i})`);
  tile.setAttribute("onmouseleave", "removeHovercircle()");
	if((i-1)%18 == 0){
	  row++;
	}

	if(row%2 == 0){
	  if(i%2 == 0){
		tile.setAttribute("class", "color2");
	  }else{
		tile.setAttribute("class", "color1");
	  }
	}else{
	  if(i%2 == 0){
		tile.setAttribute("class", "color1");
	  }else{
		tile.setAttribute("class", "color2");
	  }
	}
	document.getElementById("board").appendChild(tile);
}
  // RIVER
  var river1 = document.createElement("div");
  river1.setAttribute("id", "river1");
  document.getElementById("board").appendChild(river1);

  var bridge1 = document.createElement("div");
  bridge1.setAttribute("id", "bridge1");
  document.getElementById("board").appendChild(bridge1);

  var river2 = document.createElement("div");
  river2.setAttribute("id", "river2");
  document.getElementById("board").appendChild(river2);

  var bridge2 = document.createElement("div");
  bridge2.setAttribute("id", "bridge2");
  document.getElementById("board").appendChild(bridge2);

  var river3 = document.createElement("div");
  river3.setAttribute("id", "river3");
  document.getElementById("board").appendChild(river3);
  // TOWERS TOP
  
 // row = 0;
  for(let i = 219; i <= 454; i++){
	var tile = document.createElement("div");
	tile.setAttribute("id", `tile${i}`);
	tile.setAttribute("onclick", `cardPlayed(selectedSlot, ${i})`);
  tile.setAttribute("onmouseover", `hovering(selectedSlot, ${i})`);
  tile.setAttribute("onmouseleave", "removeHovercircle()");
	if((i-1)%18 == 0){
	  row++;
	}
	if(row%2 == 0){
	  if(i%2 == 0){
		tile.setAttribute("class", "color2");
	  }else{
		tile.setAttribute("class", "color1");
	  }
	}else{
	  if(i%2 == 0){
		tile.setAttribute("class", "color1");
	  }else{
		tile.setAttribute("class", "color2");
	  }
	}
	document.getElementById("board").appendChild(tile);

  }
  princess1top = new TowerTop(3052, 'princess1top', false);
  princess2top = new TowerTop(3052, 'princess2top', false);
  kingTop = new TowerTop(4824, 'kingTop', true);

  // TOWERS BOTTOM
  tower = document.createElement("div");
  tower.setAttribute("id", "princess1bottom");
  document.getElementById("board").appendChild(tower);
  princess1bottom = {
    div: document.getElementById("princess1bottom"), 
    health: 3052,
    taken: function(){
      tower = this.div;
      tower.style.backgroundImage = 'url("images/destroyedTower.png")';
      tower.style.backgroundRepeat = "no-repeat";
      tower.style.backgroundSize = "100% 100%";
      updateOverlay(selectedSlot);
      document.getElementById(`princess1bottomtext`).style.opacity = "0%";
    }
  }

  tower = document.createElement("div");
  tower.setAttribute("id", "princess2bottom");
  document.getElementById("board").appendChild(tower);
  princess2bottom = {
    div: document.getElementById("princess2bottom"), 
    health: 3052,
    taken: function(){
      tower = this.div;
      tower.style.backgroundImage = 'url("images/destroyedTower.png")';
      tower.style.backgroundRepeat = "no-repeat";
      tower.style.backgroundSize = "100% 100%";
      updateOverlay(selectedSlot);
      document.getElementById(`princess2bottomtext`).style.opacity = "0%";
    }
  }
  tower = document.createElement("div");
  tower.setAttribute("id", "kingBottom");
  document.getElementById("board").appendChild(tower);
  kingBottom = {
    div: document.getElementById("kingBottom"), 
    health: 4824,
    taken: function(){
      tower = this.div;
      tower.style.backgroundImage = 'url("images/destroyedTower.png")';
      tower.style.backgroundRepeat = "no-repeat";
      tower.style.backgroundSize = "100% 100%";
      document.getElementById(`kingBottomtext`).style.opacity = "0%";
      princess1bottom.taken();
      princess2bottom.taken();
      winthing();
    }
  }
  topTowers = [princess1top,princess2top,kingTop]
  bottomTowers = [princess2bottom, princess1bottom, kingBottom]
  topTowers.forEach(function(tower){
    var fontsize = (tower.div.id.includes("king")) ? 50 : 40;
    towerHealth(tower, tower.health, fontsize);
  });
  bottomTowers.forEach(function(tower){
    var fontsize = (tower.div.id.includes("king")) ? 50 : 40;
    towerHealth(tower, tower.health, fontsize);
  });
  boardRect = document.getElementById("board").getBoundingClientRect();
  document.getElementById("info").style.right = `${boardRect.left - 180}px`;
  document.getElementById("info").style.top = `${boardRect.top}px`;
}
function generateCardLink(cardVariable) {
  return `images/cards/${cardVariable}.png`;
}
function towerHealth(tower, text, size){
  var tile = tower.div;

  var tileRect = tile.getBoundingClientRect();

  var box = document.createElement("div");
  box.setAttribute("id", `${tower.div.id}text`)
  box.style.width = `${size}px`;
  box.style.pointerEvents = "none";
  box.style.height = `${size}px`;
  box.style.position = "absolute";
  box.style.backgroundColor = "lightgray";
  box.style.color = "gray";
  box.style.fontWeight = "bold";
  box.innerText = parseFloat(text);
  box.style.fontSize = `${size/2}px`;
  box.style.left = `${tileRect.left + window.pageXOffset+(tileRect.width/5)}px`;
  box.style.top = `${tileRect.top + window.pageYOffset+(tileRect.height/5)}px`;
  box.style.textAlign = "center";
  box.setAttribute("class", "game");
  document.body.appendChild(box);
}
function towerGrid(tower, tiles){
  for(let i =0; i< tiles; i++){
    var tile = document.createElement("div");
    tile.setAttribute("id", `${tower.id}T${i}`);
    tile.setAttribute("class", "game");
    tile.setAttribute("onclick", `cardPlayed(selectedSlot, "${tile.id}")`);
    tile.setAttribute("onmouseover", `hovering(selectedSlot, "${tile.id}")`);
    tile.setAttribute("onmouseleave", "removeHovercircle()");
    tower.appendChild(tile);
  }
}
function winthing(){
	clearInterval(tiebreakerInterval);
	clearInterval(elixirInterval);
	clearInterval(timeInterval);
	clearInterval(updateslotInterval);
  selectedSlot = null;
  document.getElementById("boardOverlay").style.visibility = "hidden";
  redTowers = 0;
  blueTowers = 0;
  topTowers.forEach(function(tower){
      blueTowers += (tower.health > 0) ? 0 : 1;
  });
  bottomTowers.forEach(function(tower){
      redTowers += (tower.health > 0) ? 0 : 1;
  });
//  blueTowers = countUniqueElements(towersBlue);
  var pastArena = calcArena(trophies);
  if(redTowers<blueTowers){
    var sign = "+";
    trophies+=30;
  }else{
    var sign ="-";
    trophies-=30;
  }
  var currentArena = calcArena(trophies);
  if(currentArena > pastArena){
    newArenaReached = true;
  }
  document.getElementById("board").style.pointerEvents = "none";
  document.getElementById("hand").style.pointerEvents = "none";
  document.getElementById("board").style.filter = "blur(12px)";
  var textElements = document.querySelectorAll('[id*="text"]');
  textElements.forEach(function(element) {
    element.style.filter = "blur(10px)";
  });
  setTimeout(function(/* crown holders */){
    // red crown thingy
    var box = document.createElement("div");
    var tileRect = document.querySelector(".board").getBoundingClientRect();
    box.style.width = `${tileRect.width}px`;
    box.style.height = `${tileRect.height/2}px`;
    box.setAttribute("class","winthing game");
    box.style.pointerEvents = "none";
    box.style.position = "absolute";
    box.style.left = `${tileRect.left + window.pageXOffset}px`;
    box.style.top = `${tileRect.top + window.pageYOffset}px`;
    box.innerHTML = `<br><br><br><h2>Name123456789</h2>`;
    box.style.color = "white";
    box.style.fontSize = "14px";
    box.style.textAlign = "center"
    box.style.backgroundImage = 'url("images/redthingy.png")';
    box.style.backgroundRepeat = "no-repeat";
    box.style.marginTop = `${tileRect.height/4.5}px`;
    box.style.backgroundPosition = "center top";
    document.body.appendChild(box);
    for(let i =0;i<redTowers;i++){
      var box1 = document.createElement("div");
      var redRect = box.getBoundingClientRect();
      box1.style.width = `${redRect.width/ 5.5}px`;
      box1.style.height = `${redRect.height/ 5}px`;
      if(i==1){
      box1.style.height = `${redRect.height/ 4.25}px`;
      box1.style.top = `${redRect.top + window.scrollY - 37.5}px`;
      }
      box1.setAttribute("class","winthing game");
      box1.style.pointerEvents = "none";
      box1.style.top = `${redRect.top + window.pageYOffset -50}px`;
      box1.style.left = `${redRect.left + window.pageXOffset + (40*((i*2.2)+1))}px`;
      box1.style.position = "absolute";
      box1.style.backgroundImage = 'url("images/redcrown.png")'
      box1.style.backgroundRepeat = "no-repeat";
      box1.style.backgroundSize = "100% 100%";
      document.body.appendChild(box1);

    }
    // blue thing
    box = document.createElement("div");
    box.setAttribute("class","winthing game");
    box.style.pointerEvents = "none";
    box.style.width = `${tileRect.width}px`;
    box.style.height = `${tileRect.height/2}px`;
    box.style.position = "absolute";
    box.style.left = `${tileRect.left + window.scrollX}px`;
    box.style.top = `${tileRect.top/2 + window.scrollY}px`;
    box.style.backgroundImage = 'url("images/bluethingy.png")'
    box.style.backgroundRepeat = "no-repeat";
    box.innerHTML = `<br><br><br><br><br><br><br><br><br><br><br><br><br><br><h2>${getCookie('uname')}<em>_.</em>[${sign}30<img src='images/trophy.png'width='19px'height='19px'></img>]</h2>`;
    box.style.color = "white";
    box.style.fontSize = "14px";
    box.style.textAlign = "center"
    box.style.marginTop = `${tileRect.height/4.5}px`;
    box.style.backgroundPosition = "center bottom";
    document.body.appendChild(box);
    // blue crowns 
    for(let i =0;i<blueTowers;i++){
      let box1 = document.createElement("div");
      let blueRect = box.getBoundingClientRect();
      box1.style.width = `${blueRect.width/ 5.5}px`;
      box1.style.height = `${blueRect.height/ 5}px`;
      if(i==1){
      box1.style.height = `${blueRect.height/ 4.25}px`;
      box1.style.top = `${blueRect.top + window.scrollY - 37.5}px`;
      }
      box1.setAttribute("class","winthing game");
      box1.style.pointerEvents = "none";
      box1.style.top = `${blueRect.top + window.pageYOffset +120}px`;
      box1.style.left = `${28 + blueRect.left + window.pageXOffset + (40*((i*2.2)+1))}px`;  
      
      box1.style.position = "absolute";
      box1.style.backgroundImage = 'url("images/bluecrown.png")'
      box1.style.backgroundSize = "100% 100%";
      box1.style.backgroundRepeat = "no-repeat";
      document.body.appendChild(box1);

    }
    let blueRect = box.getBoundingClientRect();
    box = document.createElement("div");
    box.setAttribute("class", "winthing game");
    box.setAttribute("onclick","hideGame(), battlePage()");
    box.style.height = `${blueRect.height/ 6}px`;
    box.style.position = "absolute";
    box.style.width = `${blueRect.width/ 3.5}px`;
    box.style.top = `${blueRect.bottom + window.scrollY}px`;
    box.style.left = `${blueRect.left + 140}px`;
    box.style.backgroundImage = 'url("images/OKbutton.png")';
    box.style.backgroundSize = "90% 90%";
    box.style.backgroundRepeat = "no-repeat";
    box.style.marginTop = "20px";
    document.body.appendChild(box);
  },1500)
}
function tiebreaker() {
  tieBreaker = true;
  var livingTowers = [];
  topTowers.forEach(function(tower){
    if(tower.health > 0){
      livingTowers.push(tower);
    }
  });
  bottomTowers.forEach(function(tower){
    if(tower.health > 0){
      livingTowers.push(tower);
    }
  });
  var damagePerTick = 2; 
  var ticks = 0;
  var damageIncrement = 2; // increment factor for increasing damage per second
  var towersAlive = livingTowers.length;
  tiebreakerInterval = setInterval(function () {
    livingTowers.forEach(function(tower){
      if(tower.health < damagePerTick){
        damagePerTick = 1;
        damageIncrement = 1;
      }
    });
    livingTowers.forEach(function(tower){
      tower.health -= damagePerTick;
      if(tower.health <= 0){
        clearInterval(tiebreakerInterval);
        tower.taken();
        livingTowers.pop();
      }
    });
  if(towersAlive == livingTowers.length){
    ticks++;
    if(ticks%225 == 0){
      damagePerTick *= damageIncrement;
    }
    if(damagePerTick > 25){
      damagePerTick = 25;
    }
  }else{
    winthing();
  }
	updateSlots();
  }, 3);
}
function hovering(selectedslot, tileNum){
  if(typeof selectedslot == "number"){
  if(typeof tileNum != "number"){
    var endTile = document.getElementById(tileNum);
  } else {
    var endTile = document.getElementById(`tile${tileNum}`);
  }
  var endTileRect = endTile.getBoundingClientRect();
 // console.log(endTileRect);
  if(deck[selectedslot].type == "spell"){
    var radius = deck[selectedslot].radius;
  } else {
    var radius = 9;
  }
  var endOffsetX = (endTile.offsetWidth - 2 * radius) / 2;
  var endOffsetY = (endTile.offsetHeight - 2 * radius) / 2;
  var styleSheet = document.styleSheets[0];
  if(document.getElementById("hovercircle") == null){
    var circle = document.createElement("div");
    circle.setAttribute("id", "hovercircle");
    styleSheet.insertRule(`#hovercircle::before { position: absolute; top: -15px; left: 50%; transform: translateX(-50%); content: "${deck[selectedslot].name}"; color: white; font-weight: bold; font-size: 20px; text-shadow: 2px 1px 2px black;}`, styleSheet.cssRules.length);
  } else {  
    var circle = document.getElementById("hovercircle");
  }

  circle.style.pointerEvents = "none";
  circle.style.width = `${2 * radius}px`;
  circle.style.height = `${2 * radius}px`;
  circle.style.borderRadius = (deck[selectedslot].type == "spell") ? "50%" : "0%" ;
  circle.style.position = "absolute";
  //circle.style.border = "4px solid gray";
  circle.style.backgroundImage = "radial-gradient(rgba(210,210,210, 0.4), rgba(210,210,210, 0.7), rgba(0,0,0,0.6))";
  circle.style.left = `${endTileRect.left + endOffsetX}px`;
  circle.style.top = `${endTileRect.top + endOffsetY}px`;
  if(document.getElementById("hovercircle") == null){
    document.body.appendChild(circle);
  }
  }
}
function cardPlayed(selectedslot, tileNum){
  if(selectedslot != null){
  for (let i = 1; i<5; i++){
    document.getElementById(`slot${i}`).style.boxShadow = "0px 0px 0px";
    document.getElementById(`slot${i}`).style.marginBottom = "0px";
  }
  if(elixirCount >= deck[selectedslot].elixirCost){
	elixirCount -= deck[selectedslot].elixirCost;
	updateElixir();
  if(deck[selectedslot].type == "spell"){
    playSpell(tileNum, deck[selectedslot].radius, deck[selectedslot].color, deck[selectedslot].duration, deck[selectedslot].flySpeed, deck[selectedslot].damage, deck[selectedslot].towerDmg);
  }else{
    playTroop(tileNum, deck[selectedslot].list);
  }

	nextCard = deck[4];
	deck.push(deck[selectedslot]);
	deck.splice(selectedslot, 1);
	deck.splice(selectedslot, 0, nextCard);
	deck.splice(4, 1);
  }
  selectedSlot = null;
  document.getElementById("boardOverlay").style.visibility = "hidden";
  document.getElementById("boardOverlay").style.pointerEvents = "none";
  }
}
function cardSelected(slotNumber){
  // slotNumber++;
  for (let i = 1; i<5; i++){
    document.getElementById(`slot${i}`).style.boxShadow = "0px 0px 0px";
    document.getElementById(`slot${i}`).style.marginBottom = "0px";
  }
  document.getElementById(`slot${slotNumber}`).style.boxShadow = "10px 10px 4px";
  document.getElementById(`slot${slotNumber}`).style.marginBottom = "10px";
  selectedSlot = slotNumber-1
  updateOverlay(selectedSlot);
}
function countElixir(){
  if(elixirCount < 10){
	elixirCount++;
  }
  updateElixir();

}
function elixirdown(){
  if(elixirCount >= 2){
	elixirCount-=2;
  }else{
	elixirCount=0;
  }
  updateElixir();
}
function setSlotAnimation(slotNum, card){
  document.getElementById(`slot${slotNum}`).style.backgroundImage = `url(${generateCardLink(card)})`;
}
function removeHovercircle(){
  if(document.getElementById("hovercircle") != null){
    document.body.removeChild(document.getElementById("hovercircle"));
  }
}
function updateSlots(){
  for(let i = 0; i < 4; i++){
    setSlotAnimation(`${i+1}`, deck[i].name)
    document.getElementById(`slot${i+1}`).style.filter = (elixirCount < deck[i].elixirCost) ? "grayscale(100%)" : "grayscale(0%)";
  }
  document.getElementById("nextcard").style.backgroundImage = `url(${generateCardLink(deck[4].name)})`;
  topTowers.forEach(function(tower){
    document.getElementById(`${tower.div.id}text`).innerText = tower.health;
  });
  bottomTowers.forEach(function(tower){
    document.getElementById(`${tower.div.id}text`).innerText = tower.health;
  });
  updateInfo(timeLeft, trophies);
  redTowers = 0;
  blueTowers = 0;
  topTowers.forEach(function(tower){
    blueTowers += (tower.health > 0) ? 1 : 0;
  });
  bottomTowers.forEach(function(tower){
    redTowers += (tower.health > 0) ? 1 : 0;
  });
  
}
function maxElixir(){
  elixirCount = 10;
}
function updateInfo(timeLeft, trophies) {
  var infoDiv = document.getElementById("info");
  var timeLeftElem = document.getElementById('timeLeft');
  var trophyImg = document.querySelector('#info img');
  var trophyCount = document.querySelector('#info b');

  if (timeLeftElem) {
	timeLeftElem.textContent = timeLeft;
  } else {
	var timeLeftElem = document.createElement('h2');
	timeLeftElem.id = 'timeLeft';
	timeLeftElem.textContent = timeLeft;
	infoDiv.appendChild(timeLeftElem);
  }

  if (!trophyImg) {
	var imgElem = document.createElement('img');
	imgElem.src = 'images/trophy.png';
	imgElem.style.width = '25px';
	imgElem.style.height = '25px';
	infoDiv.appendChild(imgElem);
  }

  if (!trophyCount) {
	var boldElem = document.createElement('b');
	boldElem.style.fontSize = '23px';
	boldElem.textContent = trophies;
	infoDiv.appendChild(boldElem);
  } else {
	trophyCount.textContent = trophies;
  }
}

function setTowerHP(team, number){
  if(team == "top"){
	kingTop.health = number;
	princess1top.health = number;
	princess2top.health = number;
  }
  if(team == "bottom"){
	kingBottom.health = number;
	princess1bottom.health = number;
	princess2bottom.health = number;
  }
}
function minusTime(){
  secondsLeft-=10;

}
function suddenDeathText(){
  label.innerHTML = "<h1 style='color: rgba(255,0,20,0.95); font-size: 32px;'>Sudden Death</h1><h1 style='color: white; font-size: 25px'>Get next crown to win!</h1>";
  setTimeout(function(){
    label.innerHTML = "<em></em>"
    label.innerHTML = "<h1 style='color: red; font-size: 30px;'>+120s</h1><h2 style='font-size: 20px; color: white;'>Extra Time</h2>";
    setTimeout(function(){
      label.innerHTML = "<em></em>";
    }, 1400)
  }, 1500);
}
function doubleText(){
  label.innerHTML = "<h1 style='color:red;font-size:35px;'>60</h1><h1 style='color: white; font-size: 25px;'>Seconds Left</h1>";
  clearInterval(elixirInterval);
  elixirInterval = setInterval(countElixir, 1400);
  setTimeout(function(){
    label.innerHTML = "<em></em>"
    label.innerHTML = "<h1 style='color: red; font-size: 30px;'> 2x Elixir</h1>";
    setTimeout(function(){
      label.innerHTML = "<em></em>";
    }, 1400)
  }, 1500);
  
}
function tripleText(){
  label.innerHTML = "<h1 style='color:red;font-size:35px;'>60</h1><h1 style='color: white; font-size: 25px;'>Seconds Left</h1>";
  clearInterval(elixirInterval);
  elixirInterval = setInterval(countElixir, 900);
  setTimeout(function(){
    label.innerHTML = "<em></em>"
    label.innerHTML = "<h1 style='color: red; font-size: 30px;'> 3x Elixir</h1>";
    setTimeout(function(){
      label.innerHTML = "<em></em>";
    }, 1400)
  }, 1500);

}
function timeDown() {
  secondsLeft -= 1;
  if (secondsLeft % 60 < 10) {
	extraZero = "0";
  } else {
	extraZero = "";
  }
  timeLeft = `${Math.floor(secondsLeft / 60)}:${extraZero}${secondsLeft % 60}`;
  updateInfo(timeLeft, trophies);
  if(secondsLeft == 60 && !overtime){
    doubleText();
  }else if(secondsLeft==60 && overtime){
    tripleText();
  }
  if (secondsLeft <= 0 && !overtime) {
	if (redTowers == blueTowers) {
	  overtime = true;
    suddenDeathText();
	  document.getElementById("timeLeft").style.backgroundColor = "rgba(255,0,0,0.35)";
	  secondsLeft = 120;
   document.getElementById("board").style.boxShadow = "10px 0 10px rgba(255, 0, 0, 0.5),-10px 0 10px rgba(255, 0, 0, 0.5)";
    //document.getElementById("screen").style.boxShadow = "10px 0 10px rgba(255, 0, 0, 0.5) inset,-10px 0 10px rgba(255, 0, 0, 0.5) inset";
	} else {
	  // End the game
	  winthing();
	  console.log("Game over");

	}
  } else if (redTowers != blueTowers && overtime) {
	// End the game
	winthing();
  } else if(overtime && secondsLeft <= 0 && !tieBreaker){
	 tiebreaker();
  }
  if(overtime && secondsLeft < 0){
    secondsLeft = 0;
    timeLeft = '0:00';
  }
}
function updateElixir(){
  for(let i =1; i <= 10;i++){
	if(elixirCount >= i){
	  document.getElementById(`elixir${i}`).style.backgroundColor = "#be0e81";
	}else{
	  document.getElementById(`elixir${i}`).style.backgroundColor = "gray";
	}
  }
}
function createLabel(){
  var rect = document.getElementById('river2').getBoundingClientRect();
  label = document.createElement('div');
  label.style.pointerEvents = "none";
  //label.style.border = "4px solid black";
  label.style.zIndex = "0";
  label.style.lineHeight = "0.6";
  label.style.width = "230px";
  label.style.textShadow = "4px 4px 7px black";
  label.style.marginLeft = 'calc(50% - 115px)';
  label.style.marginRight = 'calc(50% - 115px)';
  label.style.top = `${rect.top - 20}px`;
  label.style.height = '75px';
  label.style.textAlign = "center";
  label.style.position = 'absolute';
  label.setAttribute('id', 'label');
  document.body.appendChild(label);
}
function countUniqueElements(arr) {
  let uniqueElements = new Set(arr);
  return uniqueElements.size;
}
function calcArena(trophies){
  let arena;
  if(trophies >= 0){
	arena = 1;
  } if(trophies >= 300){
	arena = 2;
  } if(trophies >= 600){
	arena = 3;
  } if(trophies >= 1000){
	arena = 4;
  } if(trophies >= 1300){
	arena = 5;
  } if(trophies >= 1600){
	arena = 6;
  } if(trophies >= 2000){
	arena = 7;
  } if(trophies >= 2300){
	arena = 8;
  } if(trophies >= 2600){
	arena = 9;
  } if(trophies >= 3000){
	arena = 10;
  } if(trophies >= 3400){
	arena = 11;
  } if(trophies >= 3800){
	arena = 12;
  } if(trophies >= 4200){
	arena = 13;
  } if(trophies >= 4600){
	arena = 14;
  } if(trophies >= 5000){
	arena = Math.floor(15 + (trophies-5000)/500);
  }
  return(arena);
}
function restartGame(){
  clearInterval(elixirInterval);
  clearInterval(timeInterval);
  clearInterval(updateslotInterval);
  document.getElementById("board").style.pointerEvents = "all";
  document.getElementById("hand").style.pointerEvents = "all";
  elixirCount = 10;
  secondsLeft = 180;
  timeLeft = '3:00';
  overtime = false;
  princess1topTAKEN = false;
  princess2topTAKEN = false;
  kingTopTAKEN = false;
  BkingTAKEN = false;
  Bprincess1TAKEN = false;
  Bprincess2TAKEN = false;
  kingTop.health = 4824;
  kingBottom.health = 4824;
  princess1top.health = 3052;
  princess2top.health = 3052;
  princess1bottom.health = 3052;
  princess2bottom.health = 3052;
  redTowers = 0;
  blueTowers = 0;
  towersBlue = [];
  towersRed = [];
  tieBreaker = false;
  updateslotInterval = setInterval(updateSlots, 50);
  elixirInterval = setInterval(countElixir, 1500);
  timeInterval = setInterval(timeDown, 1000);
  updateElixir();
  document.getElementById("boardOverlay").style.visibility = "hidden";
  document.getElementById("board").style.boxShadow = "none";
  document.getElementById("timeLeft").style.backgroundColor = "gray";
  document.getElementById("board").style.filter = "none";
  var textElements = document.querySelectorAll('[id*="text"]');
  textElements.forEach(function(element) {
	element.style.filter = "none";
  });
  document.getElementById("kingTop").style.background = "lightgray";
  document.getElementById("princess1top").style.background = "lightgray";
  document.getElementById("princess2top").style.background = "lightgray";
  document.getElementById("kingBottom").style.background = "lightgray";
  document.getElementById("princess1bottom").style.background = "lightgray";
  document.getElementById("princess2bottom").style.background = "lightgray";
  textElements.forEach(function(element) {
	element.style.opacity = "100%";
  });
  var elements = document.querySelectorAll('.winthing');
  elements.forEach(function(element) {
	element.style.display = "none";
  })

}
