function hideGame(){
  gameElements = document.querySelectorAll('.game');
  gameElements.forEach(function(element) {
	element.style.visibility = "hidden";
	element.style.pointerEvents = "none";
  });
  clearInterval(elixirInterval);
  clearInterval(timeInterval);
  clearInterval(updateslotInterval);
}
function showGame(){
  gameElements = document.querySelectorAll('.game');
  gameElements.forEach(function(element) {
	element.style.visibility = "visible";
	element.style.pointerEvents = "all";
  });
  gameElements = document.querySelectorAll('[id*="text"]');
  gameElements.forEach(function(element) {
  element.style.pointerEvents = "none";
  });
}
function showBP(){
  if(!newArenaReached){
  bpElements = document.querySelectorAll('.bp');
  bpElements.forEach(function(element) {
	element.style.visibility = "visible";
	element.style.pointerEvents = "all";
  });}else{
	hideBP();
  }
}
function hideBP(){
  bpElements = document.querySelectorAll(".bp");
  bpElements.forEach(function(element) {
	element.style.visibility = "hidden";
	element.style.pointerEvents = "none";
  });
}
function newArena(){
  if(newArenaReached){
  var rect = document.getElementById("board").getBoundingClientRect();
  var page = document.getElementById("page");
  var arena = document.getElementById("arena");
  hideBP();
  page.style.visibility = "visible";
  arena.style.visibility = "visible";
  var newArenaText = document.createElement("div");
  newArenaText.innerHTML = "<b font-size='40px'>New Arena Reached!<b>";
  newArenaText.style.color = "rgb(230,25,185)";
  newArenaText.align = "center";
  newArenaText.position = "absolute";
  newArenaText.style.left = `${(rect.left) + window.scrollX}px`;
  newArenaText.style.top = `${rect.top + window.scrollY + rect.height}px`;
  newArenaText.style.marginLeft = "25%";
  newArenaText.style.marginRight = "25%";
  newArenaText.style.marginTop = "15%";
  newArenaText.style.background = "lightblue";
  newArenaText.style.width = "50%";
  newArenaText.style.fontSize = "30px";
  page.insertBefore(newArenaText, arena);
  arena.style.backgroundImage = `url("images/arenas/arena${calcArena(trophies)}.png")`;
  setTimeout(() => {
	showBP();
	page.removeChild(newArenaText);
  }, 4000)
  } newArenaReached = false;
}
// function loginRedir(){
//   if (getCookie("uname") == "") {
//    // window.location.replace("accounts/login.php")
//     console.log("no data");
//   }
// }
function battlePage(){  
  var rect = document.getElementById("board").getBoundingClientRect();
  var handRect = document.getElementById("hand").getBoundingClientRect();
  var page = document.createElement("div");
  document.getElementById("hand").style.left = `${rect.left}px`;
  document.getElementById("hand").style.top = `${rect.bottom}px`;
  page.setAttribute("id", "page");
  page.setAttribute("class", "bp");
  page.style.width = `${rect.width}px`;
  page.style.height = `${rect.height + handRect.height}px`;
  page.style.position = "absolute";
  page.style.backgroundColor = "#306a96";
  page.style.left = `${rect.left + window.scrollX}px`;
  page.style.top = `${rect.top + window.scrollY}px`;
  page.style.display = "flex";
  page.style.flexWrap=  "wrap";
  document.body.appendChild(page);
  var currencies = document.createElement("div");
  currencies.setAttribute("class","bp");
  currencies.style.cssText = "height: 4%; width: 90%; align-self: flex-start; margin-left: 5%; margin-right: 5%; margin-top: 4%; background-color: blue; order: 3; position: absolute;"
  page.appendChild(currencies);
  var banner = document.createElement("div");
  banner.setAttribute("class", "bp");
  banner.setAttribute("id", "banner")
  banner.style.cssText = "box-sizing: border-box; opacity: 1; border: 7px solid black; background-image: radial-gradient(lightblue, blue); width: 57.5%; height: 14%; margin-left: 0%; margin-top: 16%; align-self: flex-start; order: 1;";
  banner.style.clipPath = 'polygon(0% 0%, 100% 0%, 80% 50%, 100% 100%,0% 100%)';
  banner.setAttribute("onclick", "showProfile(), hideBP()");
  var statDisplay = document.createElement("div");
  var banner2 = document.createElement("div");
  banner2.setAttribute("class", "bp");
  banner2.setAttribute("id", "banner2");
  banner2.style.cssText = "margin-left: 0%; margin-top: 16%; order: 0; width: 57.5%; height: 14%; align-self: flex-start; position: absolute;";
  banner2.style.clipPath = 'polygon(0% 0%, 104% 0%, 85% 50%, 104% 100%, 0% 100%)';
  page.appendChild(banner);
  var bannerRect = banner.getBoundingClientRect();
  page.appendChild(banner2);
  //getBannerData(bd => {console.log(bd);colorBanner(bd.br, bd.bg, bd.dc);});
  bannerBorder = banner2.style.backgroundColor;
  bannerBG = banner.style.backgroundImage;
  statDisplay.style.order = "4";
  statDisplay.setAttribute("class","bp");
  statDisplay.style.left = `${bannerRect.left}px`;
  statDisplay.style.width = `${bannerRect.width}px`;
  statDisplay.style.height = "3.5%";
  statDisplay.style.border = '5px solid rgba(90,90,90,1)';
  statDisplay.style.backgroundColor = 'rgba(100,100,100,1)';
  statDisplay.marginTop = "0%";
  //getTrophies(trophies => {statDisplay.innerHTML = `<em>_</em><b style='color:white;'>${getCookie('uname')}</b><em>____</em><div style="float:right;"><img src='images/trophy.png'width='16px'height='16px'></img><b style="color:gold;background-color:rgb(60,60,60);"><em>__</em>${trophies}<em>__</em></b></div>`;});
  page.appendChild(statDisplay);
  var extraFeatures = document.createElement("div");
  extraFeatures.setAttribute("class", "bp");
  extraFeatures.style.cssText = "border: 4px solid black; width: 30%; height: 21%; position: absolute; margin-left: 65%; margin-right: 0%; margin-top: 16%; font-size: 8px; text-align: center;"
  extraFeatures.innerHTML = "<p>Coming Soon: Chests, card levels, accounts, bots, troops, buildings, clans, Path of legends, events, tournaments, multiplayer, leaderboards, deck builder, clan wars, seasons, banners, arenas, Pass royale, shop, fps over 10, friends, 2v2, special modes, battle log, daily quests, banner box</p>";
  page.appendChild(extraFeatures);
  var arena = document.createElement("div");
  arena.setAttribute("id", "arena");
  arena.setAttribute("class", "bp");
  arena.style.cssText = "background-size: contain; background-position: center; width: 50%; height: 36%; margin-left: 25%; margin-right: 25%; margin-bottom: 70%; align-self: center; order: 6;";
  arena.style.backgroundImage = `url("images/arenas/arena${calcArena(trophies)}.png")`;
  arena.style.backgroundRepeat = "no-repeat";
  page.appendChild(arena);
  var battleButton = document.createElement("div");
  battleButton.setAttribute("class", "bp");
  battleButton.onclick = function(){
  hideBP();
  showGame();
  restartGame();
  removePage();
  };
  battleButton.style.cssText = "position: absolute; order: 7; top: 62.5%; border-radius: 10%; height: 10%; margin-left: 33%; margin-right: 33%; width: 34%;";
  battleButton.style.backgroundImage = 'url("images/battleButton.png")';
  battleButton.style.backgroundRepeat = "no-repeat";
  battleButton.style.backgroundSize = "100% 100%";
  page.appendChild(battleButton);
  var chestHolder = document.createElement("div");
  chestHolder.setAttribute("class", "bp");
  chestHolder.style.cssText = `border: 4px solid black;width: 65%;margin-right: 17.5%;margin-left: 17.5%;order: 8;height: 18%;position: absolute;align-self: center; top: 75%;`;
  page.appendChild(chestHolder); 
  newArena();
}
function removePage(){
  document.body.removeChild(document.getElementById("page"));
}
function boardOverlay(){
  var board = document.getElementById("board");
  var boardR = board.getBoundingClientRect();
  var tileR = document.getElementById("tile1").getBoundingClientRect();
  var element = document.createElement("div");
  element.setAttribute("id", "boardOverlay");
  element.setAttribute("class", "game");
  element.style.cssText = "border: 2px solid red; background-color: rgba(255, 0, 0, 0.25); position: relative;";
  element.style.width = `${boardR.width}px`;
  element.style.height = `${boardR.height}px`;
  element.style.top = `-${boardR.height}px`;
  element.style.margin = "auto";
  document.body.appendChild(element);
}
function updateOverlay(selectedslot){
  if(selectedslot != null){
  var pathLeft = "polygon(0% 0%, 100% 0%, 100% 46%, 50% 46%, 50% 23.33%, 0% 23.33%)";
  var pathRight = "polygon(0% 0%, 100% 0%, 100% 23.33%, 50% 23.33%, 50% 46%, 0% 46%)";
  var pathBoth = "polygon(0% 0%, 100% 0%, 100% 23.33%, 0% 23.33%)";
  var pathNone = "polygon(0% 0%, 100% 0%, 100% 46%, 0% 46%)"
  var boardOverlay = document.getElementById("boardOverlay");
  if(deck[selectedslot].type == "spell"){
    boardOverlay.style.visibility = "hidden";
    boardOverlay.style.pointerEvents = "none";
  } else {
    boardOverlay.style.visibility = "visible";
    boardOverlay.style.pointerEvents = "all";
    if(princess1top.health <= 0){
      boardOverlay.style.clipPath = (princess2top.health <= 0) ? pathBoth : pathLeft ;
    } else if(princess2top.health <= 0){
      boardOverlay.style.clipPath = pathRight;
    } else {
      boardOverlay.style.clipPath = pathNone;
    }
  }
  }
}